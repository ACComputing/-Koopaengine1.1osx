#!/usr/bin/env bash
# Build Koopa Engine into a macOS executable (and optionally a .app bundle)
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Find Qt (Homebrew)
if command -v brew &>/dev/null; then
  QT_PREFIX="$(brew --prefix qt 2>/dev/null || true)"
fi
if [[ -z "$QT_PREFIX" || ! -d "$QT_PREFIX" ]]; then
  echo "Qt not found. Install with: brew install qt"
  exit 1
fi

echo "Using Qt at: $QT_PREFIX"
mkdir -p build
cd build

echo "Configuring..."
cmake .. -DCMAKE_PREFIX_PATH="$QT_PREFIX" -DCMAKE_BUILD_TYPE=Release

echo "Building..."
make -j$(sysctl -n hw.ncpu 2>/dev/null || echo 2)

EXE="$SCRIPT_DIR/build/KoopaEngine"
echo ""
echo "Build complete. Executable: $EXE"
echo "Run with: $EXE"

# Optional: create .app bundle (standalone macOS app with Qt frameworks embedded)
if [[ "$1" == "--app" ]] && [[ -x "$EXE" ]]; then
  APP_NAME="KoopaEngine.app"
  APP_DIR="$SCRIPT_DIR/build/$APP_NAME"
  CONTENTS="$APP_DIR/Contents"
  MACOS="$CONTENTS/MacOS"
  echo ""
  echo "Creating $APP_NAME bundle..."
  rm -rf "$APP_DIR"
  mkdir -p "$MACOS"
  cp "$EXE" "$MACOS/KoopaEngine"
  chmod +x "$MACOS/KoopaEngine"
  # Minimal Info.plist
  cat > "$CONTENTS/Info.plist" << 'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleExecutable</key><string>KoopaEngine</string>
  <key>CFBundleIdentifier</key><string>com.koopa.engine</string>
  <key>CFBundleName</key><string>Koopa Engine</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
</dict>
</plist>
PLIST
  # Embed Qt frameworks with macdeployqt (so app runs without Qt in PATH)
  MACDEPLOYQT="$QT_PREFIX/bin/macdeployqt"
  if [[ -x "$MACDEPLOYQT" ]]; then
    "$MACDEPLOYQT" "$APP_DIR" -always-overwrite
    echo "App bundle ready: $APP_DIR"
  else
    echo "macdeployqt not found. App bundle created but you need Qt in PATH to run it."
    echo "To get a standalone app, ensure Qt's bin is in PATH and run: $MACDEPLOYQT $APP_DIR"
  fi
fi
