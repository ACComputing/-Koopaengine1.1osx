# Koopa Engine (C++) — Clang / Qt6

## Build with Clang (CMake)

```bash
cd "/Volumes/1TB USB/###CODING/K-EngineKoopa"
mkdir -p build && cd build
cmake .. -DCMAKE_PREFIX_PATH="$(brew --prefix qt)"
make
./KoopaEngine
```

## compile_commands.json (for clangd / IDE)

CMake generates `build/compile_commands.json`. To use it from the project root:

```bash
cd build && cmake .. -DCMAKE_PREFIX_PATH="$(brew --prefix qt)" && cd ..
ln -sf build/compile_commands.json compile_commands.json
```

Then clangd and other Clang tooling will use the same flags as the build.

## .clangd

The `.clangd` file adds Qt include paths for when no `compile_commands.json` exists (e.g. before first build). If your Qt is elsewhere, edit the `-I` and `-F` paths in `.clangd`.

## Requirements

- Qt 6 (e.g. `brew install qt`)
- Clang (Xcode Command Line Tools or `brew install llvm`)
