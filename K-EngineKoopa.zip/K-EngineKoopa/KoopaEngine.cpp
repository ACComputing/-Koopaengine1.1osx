/*
 * Koopa Engine — Clickteam Fusion 3 Edition (C++)
 * Dark / Blue / Light mode · Mario Forever / Buziol Engine
 * Export: .exe .app .html .py
 *
 * Translated from Python. Build with Qt5 or Qt6.
 *   qmake && make   (or use CMake with Qt)
 */

#include <QtWidgets>
#include <QtCore>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QMessageBox>
#include <QFileDialog>
#include <QScrollBar>
#include <QApplication>
#include <QMainWindow>
#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>
#include <QSplitter>
#include <QComboBox>
#include <QCheckBox>
#include <QTextEdit>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsEllipseItem>
#include <QGraphicsTextItem>
#include <QMouseEvent>
#include <QWheelEvent>
#include <cmath>
#include <algorithm>
#include <memory>
#include <stack>
#include <vector>
#include <map>
#include <string>

// ─── Constants ─────────────────────────────────────────────────────
const int TILE_PX = 32;
const int MAX_HISTORY = 60;

// ─── Theme colors (dark / blue / light) ─────────────────────────────
struct ThemeColors {
    QString bg, panel, ribbon, tabbar, tab_act, tab_in;
    QString fg, fg2, fg3, accent, gold, sel, border, input, hover;
    QString green, red, blue, status, sfg, term, lime, grip, wspace, prop, tree, toolbar;
};

static ThemeColors themeDark() {
    return {
        "#1e1f22", "#27282c", "#2b2d30", "#2b2d30", "#1e1f22", "#2b2d30",
        "#dde1e7", "#7a8088", "#4a4e54", "#4b8ef1", "#f0a732", "#2d4a7a",
        "#3d3f45", "#35373d", "#3a3c42", "#4ec9b0", "#f44747", "#569cd6",
        "#111214", "#9ba3b0", "#111214", "#4ec9b0", "#3d3f45", "#1a1b1e",
        "#1e1f22", "#27282c", "#2b2d30"
    };
}

static ThemeColors themeBlue() {
    return {
        "#1c2740", "#1e2e50", "#16243a", "#1a2840", "#1c2740", "#1a2840",
        "#c0d4f0", "#6080b0", "#3a5070", "#3a88e8", "#f0c040", "#1e4480",
        "#283858", "#1e2e50", "#243060", "#40c890", "#e84040", "#5090d8",
        "#101828", "#80a0d0", "#0c1622", "#40e890", "#283858", "#141c34",
        "#1c2740", "#1e2e50", "#16243a"
    };
}

static ThemeColors themeLight() {
    return {
        "#f4f4f4", "#ececec", "#dcdcdc", "#e0e0e0", "#f4f4f4", "#e0e0e0",
        "#1a1a1a", "#555555", "#999999", "#0070c0", "#b86800", "#c0d8f8",
        "#c0c0c0", "#ffffff", "#e8e8e8", "#007850", "#c00000", "#0050a0",
        "#d0d0d0", "#303030", "#1e1e1e", "#008844", "#b8b8b8", "#e8e8e8",
        "#f8f8f8", "#ececec", "#dcdcdc"
    };
}

// ─── Tile definition ─────────────────────────────────────────────────
struct TileDef {
    QString color;
    QString symbol;
    bool solid;
    bool hazard;
};

// ─── Entity definition ───────────────────────────────────────────────
struct EntityDef {
    QString color;
    QString symbol;
};

// ─── Layer definition ────────────────────────────────────────────────
struct LayerDef {
    QString name;
    QString color;
};

// ─── Level properties ────────────────────────────────────────────────
struct LevelProps {
    QString name = "1-1";
    QString world_type = "grass";
    int width = 100;
    int height = 15;
    QString music = "overworld";
    double gravity = 9.8;
    int time = 300;
    QString scroll = "horizontal";
    QString background = "grass";
    int start_x = 2;
    int start_y = 12;
    bool is_castle = false;
    bool is_underwater = false;
};

// ─── Level model ────────────────────────────────────────────────────
class Level {
public:
    LevelProps props;
    std::vector<std::vector<std::vector<QString>>> layers;  // [layer][row][col]
    std::vector<std::vector<std::vector<std::vector<QString>>>> history;
    QString filepath;

    Level() { makeBlank(); }

    void makeBlank() {
        int w = props.width, h = props.height;
        layers.clear();
        for (int L = 0; L < 4; L++) {
            std::vector<std::vector<QString>> layer;
            for (int r = 0; r < h; r++) {
                std::vector<QString> row(w, L == 2 ? QString() : QString("empty"));
                layer.push_back(row);
            }
            layers.push_back(layer);
        }
    }

    QString get(int l, int r, int c) const {
        if (l < 0 || l >= (int)layers.size()) return QString();
        if (r < 0 || r >= (int)layers[l].size()) return QString();
        if (c < 0 || c >= (int)layers[l][r].size()) return QString();
        return layers[l][r][c];
    }

    void set(int l, int r, int c, const QString& v) {
        if (l < 0 || l >= (int)layers.size()) return;
        if (r < 0 || r >= (int)layers[l].size()) return;
        if (c < 0 || c >= (int)layers[l][r].size()) return;
        layers[l][r][c] = v;
    }

    void snapshot() {
        if ((int)history.size() >= MAX_HISTORY) history.erase(history.begin());
        history.push_back(layers);
    }

    bool undo() {
        if (history.empty()) return false;
        layers = history.back();
        history.pop_back();
        return true;
    }

    void floodFill(int layer, int r, int c, const QString& nv) {
        QString ov = get(layer, r, c);
        if (ov == nv) return;
        int w = props.width, h = props.height;
        std::stack<std::pair<int,int>> stack;
        stack.push({r, c});
        while (!stack.empty()) {
            int rr = stack.top().first, cc = stack.top().second;
            stack.pop();
            if (rr < 0 || rr >= h || cc < 0 || cc >= w) continue;
            if (get(layer, rr, cc) != ov) continue;
            set(layer, rr, cc, nv);
            stack.push({rr+1, cc}); stack.push({rr-1, cc});
            stack.push({rr, cc+1}); stack.push({rr, cc-1});
        }
    }

    QJsonObject toJson() const {
        QJsonObject o;
        QJsonObject p;
        p["name"] = props.name;
        p["world_type"] = props.world_type;
        p["width"] = props.width;
        p["height"] = props.height;
        p["music"] = props.music;
        p["gravity"] = props.gravity;
        p["time"] = props.time;
        p["scroll"] = props.scroll;
        p["background"] = props.background;
        p["start_x"] = props.start_x;
        p["start_y"] = props.start_y;
        p["is_castle"] = props.is_castle;
        p["is_underwater"] = props.is_underwater;
        o["props"] = p;
        QJsonArray layersArr;
        for (const auto& layer : layers) {
            QJsonArray layerArr;
            for (const auto& row : layer) {
                QJsonArray rowArr;
                for (const QString& cell : row)
                    rowArr.append(cell.isNull() ? QJsonValue() : QJsonValue(cell));
                layerArr.append(rowArr);
            }
            layersArr.append(layerArr);
        }
        o["layers"] = layersArr;
        return o;
    }

    static Level fromJson(const QJsonObject& o) {
        Level l;
        QJsonObject p = o["props"].toObject();
        l.props.name = p["name"].toString();
        l.props.world_type = p["world_type"].toString();
        l.props.width = p["width"].toInt(100);
        l.props.height = p["height"].toInt(15);
        l.props.music = p["music"].toString();
        l.props.gravity = p["gravity"].toDouble(9.8);
        l.props.time = p["time"].toInt(300);
        l.props.scroll = p["scroll"].toString();
        l.props.background = p["background"].toString();
        l.props.start_x = p["start_x"].toInt(2);
        l.props.start_y = p["start_y"].toInt(12);
        l.props.is_castle = p["is_castle"].toBool();
        l.props.is_underwater = p["is_underwater"].toBool();
        l.layers.clear();
        QJsonArray layersArr = o["layers"].toArray();
        for (const QJsonValue& lv : layersArr) {
            QJsonArray layerArr = lv.toArray();
            std::vector<std::vector<QString>> layer;
            for (const QJsonValue& rv : layerArr) {
                QJsonArray rowArr = rv.toArray();
                std::vector<QString> row;
                for (const QJsonValue& cv : rowArr)
                    row.push_back(cv.isNull() ? QString() : cv.toString());
                layer.push_back(row);
            }
            l.layers.push_back(layer);
        }
        return l;
    }
};

// ─── Global tile/entity/theme maps (populated in init) ────────────────
static std::map<QString, TileDef> TILES;
static std::map<QString, EntityDef> ENTITIES;
static std::map<QString, QString> BG_COLORS;
static std::vector<LayerDef> LAYER_DEFS;
static ThemeColors T;
static QString CUR_THEME = "dark";

static void initData() {
    if (!TILES.empty()) return;
    TILES["empty"]       = {"#1e1f22", " ",   false, false};
    TILES["ground"]      = {"#7a4f2c", "\u2593", true, false};
    TILES["grass_top"]   = {"#5aad3c", "\u2580", true, false};
    TILES["brick"]       = {"#c0603a", "\u25A6", true, false};
    TILES["hard_block"]  = {"#9b6b3c", "\u25A0", true, false};
    TILES["?_block"]     = {"#e8ab4f", "?", true, false};
    TILES["used_block"]  = {"#888060", "\u25A1", true, false};
    TILES["pipe_top_l"]  = {"#3cb03c", "\u2554", true, false};
    TILES["pipe_top_r"]  = {"#2d9a2d", "\u2557", true, false};
    TILES["platform"]    = {"#8b6914", "\u2550", true, false};
    TILES["lava"]        = {"#e83800", "\u224B", false, true};
    TILES["spike"]       = {"#cccccc", "\u25B2", false, true};
    TILES["start_pos"]   = {"#00ff88", "S", false, false};
    TILES["end_pos"]     = {"#ff8800", "E", false, false};

    ENTITIES["Player"]   = {"#ff4444", "P"};
    ENTITIES["Goomba"]   = {"#c08030", "G"};
    ENTITIES["Koopa"]    = {"#38c038", "K"};
    ENTITIES["Coin (obj)"] = {"#ffd700", "\u00A2"};

    BG_COLORS["grass"] = "#5c94fc";
    BG_COLORS["underground"] = "#000000";
    BG_COLORS["water"] = "#080838";

    LAYER_DEFS = {
        {"Background", "#1a3a5c"},
        {"Tiles", "#3a6a2c"},
        {"Entities", "#8a2a2a"},
        {"Foreground", "#3a3a8a"}
    };
}

// ─── Editor canvas (QGraphicsView) ───────────────────────────────────
class EditorCanvas : public QGraphicsView {
public:
    Level* level = nullptr;
    ThemeColors* theme = nullptr;
    int activeLayer = 1;
    QString activeTile = "ground";
    QString activeEnt = "Player";
    QString tool = "paint";
    double zoom = 1.0;
    bool showGrid = true;
    std::vector<bool> layerVis = {true,true,true,true};
    std::vector<bool> layerLock = {false,false,false,false};
    bool drag = false;
    bool eraseDragActive = false;
    std::function<void(int,int)> onStatus;
    std::function<void()> onRedrawMinimap;
    std::function<void(double)> onZoomRequested;

    explicit EditorCanvas(QWidget* parent = nullptr) : QGraphicsView(parent) {
        setScene(new QGraphicsScene(this));
        setRenderHint(QPainter::Antialiasing, false);
        setDragMode(QGraphicsView::NoDrag);
        setTransformationAnchor(QGraphicsView::AnchorViewCenter);
        setResizeAnchor(QGraphicsView::AnchorViewCenter);
    }

    void setLevel(Level* l) { level = l; }
    void setTheme(ThemeColors* t) { theme = t; }

    int tileSize() const { return std::max(4, (int)(TILE_PX * zoom)); }

    void redraw() {
        if (!level || !theme) return;
        QGraphicsScene* sc = scene();
        sc->clear();
        int w = level->props.width, h = level->props.height;
        int px = tileSize();
        QString bgKey = level->props.background.isEmpty() ? level->props.world_type : level->props.background;
        QString bgHex = BG_COLORS.count(bgKey) ? BG_COLORS[bgKey] : "#5c94fc";
        sc->setBackgroundBrush(QColor(bgHex));
        sc->setSceneRect(0, 0, w * px + 80, h * px + 80);

        for (int li = 0; li < 4; li++) {
            if (li >= (int)layerVis.size() || !layerVis[li]) continue;
            for (int r = 0; r < h; r++) {
                for (int c = 0; c < w; c++) {
                    QString cell = level->get(li, r, c);
                    if (cell.isEmpty() || cell == "empty") continue;
                    int x1 = c * px, y1 = r * px, x2 = x1 + px, y2 = y1 + px;
                    if (li == 2) {
                        if (ENTITIES.count(cell)) {
                            EntityDef ed = ENTITIES[cell];
                            QGraphicsEllipseItem* el = sc->addEllipse(x1+2, y1+2, px-4, px-4, QPen(Qt::white), QBrush(QColor(ed.color)));
                            el->setZValue(1);
                            QGraphicsTextItem* tx = sc->addText(ed.symbol);
                            tx->setDefaultTextColor(Qt::white);
                            tx->setPos(x1 + px/2 - tx->boundingRect().width()/2, y1 + px/2 - tx->boundingRect().height()/2);
                            tx->setZValue(2);
                        }
                    } else {
                        if (TILES.count(cell)) {
                            TileDef td = TILES[cell];
                            sc->addRect(x1, y1, px, px, QPen(), QBrush(QColor(td.color)));
                            if (px >= 14) {
                                QGraphicsTextItem* tx = sc->addText(td.symbol);
                                tx->setDefaultTextColor(Qt::white);
                                tx->setPos(x1 + px/2 - tx->boundingRect().width()/2, y1 + px/2 - tx->boundingRect().height()/2);
                            }
                        }
                    }
                }
            }
        }

        if (showGrid) {
            QString gc = (bgHex == "#000000" || bgHex == "#101010") ? "#444466" : "#aaaacc";
            QPen gridPen{QColor(gc)};
            for (int c = 0; c <= w; c++) sc->addLine(c*px, 0, c*px, h*px, gridPen);
            for (int r = 0; r <= h; r++) sc->addLine(0, r*px, w*px, r*px, gridPen);
        }
        if (onRedrawMinimap) onRedrawMinimap();
    }

protected:
    void mousePressEvent(QMouseEvent* e) override {
        if (!level) return;
        QPointF pos = mapToScene(e->pos());
        int px = tileSize();
        int r = (int)(pos.y() / px), c = (int)(pos.x() / px);
        if (e->button() == Qt::LeftButton) {
            level->snapshot();
            if (tool == "fill") {
                QString v = (activeLayer == 2) ? activeEnt : activeTile;
                level->floodFill(activeLayer, r, c, v);
            } else
                paintAt(r, c);
            drag = true;
        } else if (e->button() == Qt::RightButton || e->button() == Qt::MiddleButton) {
            if (activeLayer < (int)layerLock.size() && layerLock[activeLayer]) return;
            level->snapshot();
            eraseDragActive = true;
            eraseAt(r, c);
        }
        if (onStatus) onStatus(r, c);
    }

    void mouseMoveEvent(QMouseEvent* e) override {
        QPointF pos = mapToScene(e->pos());
        int px = tileSize();
        int r = (int)(pos.y() / px), c = (int)(pos.x() / px);
        if (drag) {
            paintAt(r, c);
        } else if (eraseDragActive) {
            eraseAt(r, c);
        }
        if (onStatus) onStatus(r, c);
    }

    void mouseReleaseEvent(QMouseEvent* e) override {
        if (e->button() == Qt::LeftButton) drag = false;
        else if (e->button() == Qt::RightButton || e->button() == Qt::MiddleButton) eraseDragActive = false;
    }

    void wheelEvent(QWheelEvent* e) override {
        if (e->modifiers() & Qt::ControlModifier) {
            double factor = e->angleDelta().y() > 0 ? 1.1 : 0.9;
            if (onZoomRequested) onZoomRequested(factor);
        } else {
            QGraphicsView::wheelEvent(e);
        }
    }

private:
    void paintAt(int r, int c) {
        if (!level) return;
        int w = level->props.width, h = level->props.height;
        if (r < 0 || r >= h || c < 0 || c >= w) return;
        if (activeLayer < (int)layerLock.size() && layerLock[activeLayer]) return;
        if (tool == "paint" || tool == "entity") {
            QString v = (activeLayer == 2) ? activeEnt : activeTile;
            if (tool == "entity") v = activeEnt;
            else if (activeLayer != 2) v = activeTile;
            level->set(activeLayer, r, c, v);
        } else if (tool == "erase") {
            level->set(activeLayer, r, c, activeLayer == 2 ? QString() : QString("empty"));
        }
        redraw();
    }

    void eraseAt(int r, int c) {
        if (!level) return;
        int w = level->props.width, h = level->props.height;
        if (r < 0 || r >= h || c < 0 || c >= w) return;
        level->set(activeLayer, r, c, activeLayer == 2 ? QString() : QString("empty"));
        redraw();
    }
};

// ─── Main window ─────────────────────────────────────────────────────
class KoopaEngineMainWindow : public QMainWindow {
public:
    Level level;
    EditorCanvas* canvas = nullptr;
    QLabel* statusLeft = nullptr;
    QLabel* statusRight = nullptr;
    QTextEdit* logEdit = nullptr;
    QGraphicsView* minimap = nullptr;
    QComboBox* layerCombo = nullptr;
    QLabel* zoomLabel = nullptr;
    ThemeColors theme;

    KoopaEngineMainWindow(QWidget* parent = nullptr) : QMainWindow(parent) {
        initData();
        theme = themeDark();
        setWindowTitle("Koopa Engine · Clickteam Fusion 3 Edition (C++)");
        setMinimumSize(1024, 680);
        resize(1440, 900);
        setStyleSheet(QString("background-color: %1;").arg(theme.bg));

        buildUi();
        canvas->redraw();
        log("Koopa Engine — Clickteam Fusion 3 Edition (C++)", "mario");
        log(QString("Level '%1' %2x%3 tiles ready").arg(level.props.name).arg(level.props.width).arg(level.props.height), "success");
        log("P=Paint E=Erase F=Fill T=Entity G=Grid Right-click=delete Ctrl+Z=Undo", "info");
    }

    void buildUi() {
        QWidget* central = new QWidget(this);
        setCentralWidget(central);
        QVBoxLayout* mainLay = new QVBoxLayout(central);
        mainLay->setSpacing(0);
        mainLay->setContentsMargins(0,0,0,0);

        // Menu bar (Qt 6.4+ addAction(text, shortcut, object, slot))
        QMenuBar* menuBar = this->menuBar();
        QMenu* fileMenu = menuBar->addMenu("&File");
        fileMenu->addAction("New", QKeySequence::New, this, [this](){ newLevel(); });
        fileMenu->addAction("Open...", QKeySequence::Open, this, [this](){ openLevel(); });
        fileMenu->addAction("Save", QKeySequence::Save, this, [this](){ saveLevel(); });
        fileMenu->addAction("Save As...", this, [this](){ saveAs(); });
        fileMenu->addSeparator();
        fileMenu->addAction("Exit", QKeySequence::Quit, this, &QWidget::close);

        QMenu* editMenu = menuBar->addMenu("&Edit");
        editMenu->addAction("Undo", QKeySequence::Undo, this, [this](){ undo(); });
        editMenu->addAction("Clear", this, [this](){ clearAll(); });

        QMenu* runMenu = menuBar->addMenu("&Run");
        runMenu->addAction("Run", QKeySequence(Qt::Key_F5), this, [this](){ runPreview(); });

        // Toolbar
        QToolBar* bar = addToolBar("Main");
        bar->addAction("New", [this](){ newLevel(); });
        bar->addAction("Open", [this](){ openLevel(); });
        bar->addAction("Save", [this](){ saveLevel(); });
        bar->addAction("Undo", [this](){ undo(); });
        bar->addSeparator();
        bar->addAction("Paint", [this](){ setTool("paint"); });
        bar->addAction("Erase", [this](){ setTool("erase"); });
        bar->addAction("Fill", [this](){ setTool("fill"); });
        bar->addAction("Entity", [this](){ setTool("entity"); });
        bar->addSeparator();
        zoomLabel = new QLabel("100%");
        bar->addWidget(zoomLabel);
        bar->addAction("+", [this](){ setZoom(canvas->zoom * 1.25); });
        bar->addAction("-", [this](){ setZoom(canvas->zoom / 1.25); });
        bar->addSeparator();
        layerCombo = new QComboBox;
        for (const auto& ld : LAYER_DEFS) layerCombo->addItem(ld.name);
        layerCombo->setCurrentIndex(1);
        connect(layerCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), [this](int i){ canvas->activeLayer = i; });
        bar->addWidget(new QLabel(" Layer: "));
        bar->addWidget(layerCombo);
        bar->addAction("Run F5", [this](){ runPreview(); });

        // Center: canvas
        canvas = new EditorCanvas(this);
        canvas->setLevel(&level);
        canvas->setTheme(&theme);
        canvas->onStatus = [this](int r, int c) {
            if (statusRight && canvas->activeLayer < (int)LAYER_DEFS.size())
                statusRight->setText(QString("Row %1, Col %2 | %3").arg(r).arg(c).arg(LAYER_DEFS[canvas->activeLayer].name));
        };
        canvas->onRedrawMinimap = [this](){ drawMinimap(); };
        canvas->onZoomRequested = [this](double f){ setZoom(canvas->zoom * f); };
        mainLay->addWidget(canvas, 1);

        // Log
        logEdit = new QTextEdit(this);
        logEdit->setMaximumHeight(140);
        logEdit->setReadOnly(true);
        logEdit->setStyleSheet(QString("background: %1; color: %2; font-family: Consolas;").arg(theme.term).arg(theme.lime));
        mainLay->addWidget(logEdit);

        // Status bar
        QStatusBar* sb = statusBar();
        statusLeft = new QLabel("  Ready | Koopa Engine · Mario Forever / Buziol");
        statusRight = new QLabel("Row 0, Col 0 | Tiles");
        sb->addWidget(statusLeft, 1);
        sb->addPermanentWidget(statusRight);

        // Minimap (optional, in a dock or corner)
        minimap = new QGraphicsView(this);
        minimap->setFixedSize(226, 68);
        minimap->setScene(new QGraphicsScene(this));
    }

    void drawMinimap() {
        if (!minimap || !minimap->scene()) return;
        QGraphicsScene* sc = minimap->scene();
        sc->clear();
        int w = level.props.width, h = level.props.height;
        if (w <= 0 || h <= 0) return;
        double tw = 226.0 / w, th = 68.0 / h;
        QString bgHex = BG_COLORS.count(level.props.background) ? BG_COLORS[level.props.background] : "#5c94fc";
        sc->setBackgroundBrush(QColor(bgHex));
        for (int r = 0; r < h; r++)
            for (int c = 0; c < w; c++) {
                QString cell = level.get(1, r, c);
                if (cell.isEmpty() || cell == "empty") continue;
                if (TILES.count(cell))
                    sc->addRect(c*tw, r*th, tw+1, th+1, QPen(), QBrush(QColor(TILES[cell].color)));
            }
        for (int r = 0; r < h; r++)
            for (int c = 0; c < w; c++) {
                QString cell = level.get(2, r, c);
                if (cell.isEmpty()) continue;
                if (ENTITIES.count(cell))
                    sc->addEllipse(c*tw, r*th, tw, th, QPen(), QBrush(QColor(ENTITIES[cell].color)));
            }
    }

    void newLevel() {
        level = Level();
        canvas->redraw();
        log("New level.", "success");
    }

    void openLevel() {
        QString path = QFileDialog::getOpenFileName(this, "Open", QString(), "Koopa Level (*.klvl *.json);;All (*.*)");
        if (path.isEmpty()) return;
        QFile f(path);
        if (!f.open(QIODevice::ReadOnly)) { QMessageBox::critical(this, "Error", "Could not open file."); return; }
        QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
        f.close();
        level = Level::fromJson(o);
        level.filepath = path;
        canvas->redraw();
        log("Opened: " + path, "success");
    }

    void saveLevel() {
        if (!level.filepath.isEmpty()) doSave(level.filepath);
        else saveAs();
    }

    void saveAs() {
        QString path = QFileDialog::getSaveFileName(this, "Save", QString(), "Koopa Level (*.klvl *.json);;All (*.*)");
        if (path.isEmpty()) return;
        level.filepath = path;
        doSave(path);
    }

    void doSave(const QString& path) {
        QFile f(path);
        if (!f.open(QIODevice::WriteOnly)) { QMessageBox::critical(this, "Error", "Could not save."); return; }
        f.write(QJsonDocument(level.toJson()).toJson(QJsonDocument::Indented));
        f.close();
        log("Saved: " + path, "success");
    }

    void undo() {
        if (level.undo()) { canvas->redraw(); log("Undo", "warn"); }
        else log("Nothing to undo", "warn");
    }

    void clearAll() {
        if (QMessageBox::Yes != QMessageBox::question(this, "Clear", "Clear ALL layers?", QMessageBox::Yes | QMessageBox::No, QMessageBox::No))
            return;
        level.snapshot();
        level.makeBlank();
        canvas->redraw();
        log("Cleared.", "warn");
    }

    void setTool(const QString& key) { canvas->tool = key; }
    void setZoom(double z) {
        canvas->zoom = qBound(0.25, z, 4.0);
        if (zoomLabel) zoomLabel->setText(QString("%1%").arg((int)(canvas->zoom * 100)));
        canvas->redraw();
    }

    void runPreview() {
        QString outDir = QFileDialog::getExistingDirectory(this, "Select Output Folder");
        if (outDir.isEmpty()) return;
        QString pyPath = outDir + "/main.py";
        QString code = genPygame();
        QFile f(pyPath);
        if (!f.open(QIODevice::WriteOnly)) { QMessageBox::critical(this, "Error", "Could not write main.py"); return; }
        f.write(code.toUtf8());
        f.close();
        log("Exported -> " + pyPath, "success");
        QProcess::startDetached("python3", QStringList() << pyPath, outDir);
    }

    QString genPygame() {
        LevelProps& p = level.props;
        QString td = tileDataJson();
        QString ed = entityDataJson();
        QString bg = BG_COLORS.count(p.background) ? BG_COLORS[p.background] : "#5c94fc";
        int r = bg.mid(1,2).toInt(nullptr, 16), g = bg.mid(3,2).toInt(nullptr, 16), b = bg.mid(5,2).toInt(nullptr, 16);
        return QString(
R"(#!/usr/bin/env python3
# Auto-generated by Koopa Engine (C++ Edition)
import pygame, sys, asyncio, random
SW,SH=600,400; TS=32
GRAVITY=%1
BG_COLOR=(%2,%3,%4)
LEVEL_NAME="%5"
LEVEL_TIME=%6
TILE_MAP=%7
ENTITY_LIST=%8
pygame.init()
screen=pygame.display.set_mode((SW,SH))
clock=pygame.time.Clock()
async def main():
    running=True
    while running:
        for ev in pygame.event.get():
            if ev.type==pygame.QUIT: running=False
        screen.fill(BG_COLOR)
        pygame.display.flip()
        await asyncio.sleep(0)
    pygame.quit(); sys.exit()
if __name__=="__main__": asyncio.run(main())
)").arg(p.gravity).arg(r).arg(g).arg(b).arg(p.name).arg(p.time).arg(td).arg(ed);
    }

    QString tileDataJson() {
        QJsonArray arr;
        int w = level.props.width, h = level.props.height;
        if (level.layers.size() < 2) return "[]";
        const auto& layer = level.layers[1];
        for (int r = 0; r < h; r++) {
            QJsonArray row;
            for (int c = 0; c < w; c++) {
                QString cell = level.get(1, r, c);
                row.append(cell.isEmpty() || cell == "empty" ? QJsonValue() : QJsonValue(cell));
            }
            arr.append(row);
        }
        return QString::fromUtf8(QJsonDocument(arr).toJson(QJsonDocument::Compact));
    }

    QString entityDataJson() {
        QJsonArray arr;
        int w = level.props.width, h = level.props.height;
        if (level.layers.size() < 3) return "[]";
        for (int r = 0; r < h; r++)
            for (int c = 0; c < w; c++) {
                QString cell = level.get(2, r, c);
                if (cell.isEmpty()) continue;
                QJsonObject o;
                o["type"] = cell;
                o["x"] = c;
                o["y"] = r;
                arr.append(o);
            }
        return QString::fromUtf8(QJsonDocument(arr).toJson(QJsonDocument::Compact));
    }

    void log(const QString& msg, const QString& tag = "info") {
        QString ts = QTime::currentTime().toString("hh:mm:ss");
        if (logEdit) {
            logEdit->append(QString("[%1] ").arg(ts) + msg);
        }
    }

protected:
    void keyPressEvent(QKeyEvent* e) override {
        if (e->key() == Qt::Key_G) { canvas->showGrid = !canvas->showGrid; canvas->redraw(); }
        if (e->key() == Qt::Key_P) canvas->tool = "paint";
        if (e->key() == Qt::Key_E) canvas->tool = "erase";
        if (e->key() == Qt::Key_F) canvas->tool = "fill";
        if (e->key() == Qt::Key_T) canvas->tool = "entity";
        QMainWindow::keyPressEvent(e);
    }
};

// ─── main ────────────────────────────────────────────────────────────
int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    KoopaEngineMainWindow w;
    w.show();
    return app.exec();
}
